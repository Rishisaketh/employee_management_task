from django.db import models
import uuid

class Employee(models.Model):
   # regid = models.CharField(max_length=10, unique=True, default=str(uuid.uuid4()))
    regid = models.CharField(max_length=10, default=str(uuid.uuid4()), unique=True)
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    age = models.IntegerField()
    gender = models.CharField(max_length=10)
    phoneNo = models.CharField(max_length=20)
    addressDetails = models.JSONField()
    workExperience = models.JSONField()
    qualifications = models.JSONField()
    projects = models.JSONField()
    photo = models.TextField()

