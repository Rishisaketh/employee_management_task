from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Employee
from .serializers import EmployeeSerializer


@api_view(['POST'])
def create_employee(request):
    try:
        # regid id generate
        existing_employee_count = Employee.objects.count()
        new_regid = f'EMP{existing_employee_count + 1:03}'  

        # Create a new employee with the generated regid
        employee_data = request.data
        employee_data['regid'] = new_regid
        serializer = EmployeeSerializer(data=employee_data)

        if serializer.is_valid():
            serializer.save()
            return Response(
                {"message": "Employee created successfully", "regid": new_regid, "success": True},
                status=status.HTTP_200_OK
            )
        else:
            return Response(
                {"message": "Invalid body request", "success": False},
                status=status.HTTP_400_BAD_REQUEST
            )

    except Exception as e:
        return Response(
            {"message": "Employee creation failed", "success": False},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@api_view(['PUT'])
def update_employee(request, regid):
    try:
        # Find the employee based on the 'regid'
        employee = Employee.objects.get(regid=regid)

        # Update employee details based on the request data
        employee_data = request.data

        # Ensure that the 'regid' is not being changed
        employee_data['regid'] = regid  
        
        serializer = EmployeeSerializer(employee, data=employee_data, partial=True)

        if serializer.is_valid():
            serializer.save()
            return Response(
                {"message": "Employee details updated successfully", "success": True},
                status=status.HTTP_200_OK
            )
        else:
            return Response(
                {"message": "Invalid body request", "success": False},
                status=status.HTTP_400_BAD_REQUEST
            )

    except Employee.DoesNotExist:
        return Response(
            {"message": "No employee found with this regid", "success": False},
            status=status.HTTP_200_OK
        )

    except Exception as e:
        return Response(
            {"message": "Employee updation failed", "success": False},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
    
# Delete Employee View
@api_view(['DELETE'])
def delete_employee(request, regid):
    if request.method == 'DELETE':
        try:
            employee = Employee.objects.get(regid=regid)
            employee.delete()
            return Response({
                "message": "Employee deleted successfully",
                "success": True
            }, status=status.HTTP_200_OK)
        except Employee.DoesNotExist:
            return Response({
                "message": "No employee found with this regid",
                "success": False
            }, status=status.HTTP_200_OK)


# Get Employee View
@api_view(['GET'])
def get_employee(request):
    regid = request.query_params.get('regid', None)
    if regid:
        try:
            employee = Employee.objects.get(regid=regid)
            serializer = EmployeeSerializer(employee)
            return Response({
                "message": "Employee details found",
                "success": True,
                "employee": serializer.data
            }, status=status.HTTP_200_OK)
        except Employee.DoesNotExist:
            return Response({
                "message": "No employee found with this regid",
                "success": False
            }, status=status.HTTP_200_OK)
    else:
        employees = Employee.objects.all()
        serializer = EmployeeSerializer(employees, many=True)
        return Response({
            "message": "Employee details found",
            "success": True,
            "employees": serializer.data
        }, status=status.HTTP_200_OK)
