from django.urls import path
from .views import create_employee, update_employee, delete_employee, get_employee

urlpatterns = [
    path('employee/create/', create_employee, name='create_employee'),
    path('employee/update/<str:regid>/', update_employee, name='update_employee'),
    path('employee/delete/<str:regid>/', delete_employee, name='delete_employee'),
    path('employees/', get_employee, name='get_employee'),
]
